# utils/runner.py
import subprocess
import time
import logging

# Set up a dedicated logger for command errors
logger = logging.getLogger('CommandRunner')
file_handler = logging.FileHandler('recon_errors.log')
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)
logger.setLevel(logging.ERROR)

def run_command(command: str, task_description: str, progress, task_id):
    """
    A robust function to run an external command, handle errors, and update progress.
    """
    start_time = time.time()
    try:
        progress.update(task_id, description=f"[cyan]RUNNING: {task_description}")
        
        # Using shell=False is safer, command should be a list of args
        # For simplicity in this example, shell=True is used with a full string.
        # In a production tool, parse the command into a list of arguments.
        process = subprocess.run(
            command,
            shell=True,
            check=True,
            capture_output=True,
            text=True
        )
        
        elapsed_time = time.time() - start_time
        progress.update(task_id, description=f"[green]DONE: {task_description} ({elapsed_time:.2f}s)", advance=100)
        return process.stdout

    except subprocess.CalledProcessError as e:
        error_message = (
            f"Command failed: {task_description}\n"
            f"Command: {e.cmd}\n"
            f"Return Code: {e.returncode}\n"
            f"Stderr: {e.stderr.strip()}"
        )
        logger.error(error_message)
        progress.update(task_id, description=f"[red]FAILED: {task_description}")
        return None