# phases/1_enumerate.py
from concurrent.futures import ThreadPoolExecutor
from utils.runner import run_command

def run(target, output_dir, deep_scan, config, progress):
    """Phase 1: Subdomain Enumeration"""
    task_id = progress.add_task("[yellow]Enumeration", total=100)
    
    all_subs_file = f"{output_dir}/all_subs.txt"
    subfinder_out = f"{output_dir}/subfinder.txt"
    amass_out = f"{output_dir}/amass.txt"
    assetfinder_out = f"{output_dir}/assetfinder.txt"
    
    # Concurrent execution of passive tools
    with ThreadPoolExecutor(max_workers=config['concurrency']) as executor:
        futures = []
        futures.append(executor.submit(run_command, f"subfinder -d {target} -o {subfinder_out} -silent", "Subfinder", progress, task_id))
        futures.append(executor.submit(run_command, f"amass enum -passive -d {target} -o {amass_out}", "Amass (Passive)", progress, task_id))
        futures.append(executor.submit(run_command, f"assetfinder --subs-only {target}", "Assetfinder", progress, task_id))
        
        # Wait for all passive tasks to complete
        results = [f.result() for f in futures]

    # Combine all results and de-duplicate
    unique_subs = set()
    if results[0]: # Subfinder output file
        with open(subfinder_out, 'r') as f:
            unique_subs.update(line.strip() for line in f)
    if results[1]: # Amass output file
        with open(amass_out, 'r') as f:
            unique_subs.update(line.strip() for line in f)
    if results[2]: # Assetfinder stdout
        unique_subs.update(results[2].strip().split('\n'))

    if deep_scan:
        ffuf_out = f"{output_dir}/ffuf.txt"
        wordlist = config['wordlists']['subdomains']
        if run_command(f"ffuf -w {wordlist} -u https://FUZZ.{target} -mc 200,301,302 -o {ffuf_out} -of csv -silent", "FFUF Brute-force", progress, task_id):
            with open(ffuf_out, 'r') as f:
                # ffuf csv format: FUZZ,url,position,status,length...
                unique_subs.update(f"{line.split(',')[0]}.{target}" for line in f)

    with open(all_subs_file, 'w') as f:
        for sub in sorted(list(unique_subs)):
            f.write(f"{sub}\n")
            
    progress.update(task_id, description="[green]DONE: Enumeration Phase")