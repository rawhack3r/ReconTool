# phases/2_scan.py
from utils.runner import run_command

def run(target, output_dir, deep_scan, config, progress):
    """Phase 2: Scanning and Probing"""
    task_id = progress.add_task("[yellow]Scanning", total=100)
    
    all_subs_file = f"{output_dir}/all_subs.txt"
    live_hosts_file = f"{output_dir}/live_hosts.txt"
    port_scan_file = f"{output_dir}/port_scan.txt"
    
    # Run httpx to find live web servers
    run_command(f"httpx -l {all_subs_file} -o {live_hosts_file} -tech-detect -status-code -silent", "HTTPX (Live Hosts)", progress, task_id)

    if deep_scan:
        # Run Naabu for port scanning on all subs
        port_range = config['tools']['port_scan_range']
        run_command(f"naabu -l {all_subs_file} -p {port_range} -o {port_scan_file} -silent", "Naabu (Port Scan)", progress, task_id)
        
    progress.update(task_id, description="[green]DONE: Scanning Phase")