# phases/3_discover.py
from utils.runner import run_command

def run(target, output_dir, config, progress):
    """Phase 3: Discovery and Analysis"""
    task_id = progress.add_task("[yellow]Discovery", total=100)
    
    live_hosts_file = f"{output_dir}/live_hosts.txt"
    nuclei_out = f"{output_dir}/nuclei_findings.txt"
    wayback_out = f"{output_dir}/wayback_urls.txt"
    
    # Run Waybackurls and Gau
    run_command(f"echo {target} | gau --subs", "GAU (Wayback URLs)", progress, task_id)
    run_command(f"echo {target} | waybackurls", "Waybackurls", progress, task_id)
    # Note: In a real tool, you would combine and process these results.

    # Run Nuclei on live hosts
    templates = config['tools']['nuclei_templates']
    run_command(f"nuclei -l {live_hosts_file} -t {templates} -o {nuclei_out} -silent", "Nuclei (Vuln Scan)", progress, task_id)

    progress.update(task_id, description="[green]DONE: Discovery Phase")