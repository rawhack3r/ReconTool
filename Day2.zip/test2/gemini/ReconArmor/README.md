# ReconArmor v1.0 🛡️

ReconArmor is a comprehensive, modular, and concurrent reconnaissance framework designed for bug bounty hunters and penetration testers. [cite_start]Its workflow is inspired by the methodologies of industry-standard tools like **reconftw** and **bbot**, aiming to provide the **best possible recon output** while balancing **speed** and **resource consumption**[cite: 3, 11].

## Key Features

-   **Futuristic & Rich UI**: Uses a dynamic, real-time display to track progress across different phases.
-   **Concurrent Execution**: Runs non-dependent tools simultaneously (e.g., Subfinder, Amass, Assetfinder) to drastically reduce scan times.
-   **Phased & Modular Workflow**: The reconnaissance process is broken down into logical phases, and each tool is a module, making it highly customizable.
-   [cite_start]**Default vs. Deep Scans**: Offers a fast, passive-only `default` mode and a thorough `deep` mode that includes active brute-forcing and full port scanning[cite: 9].
-   [cite_start]**Robust Error Handling**: Skips any failing tool, logs the error with the exact command and output, and continues the workflow to ensure completion[cite: 7].
-   **Centralized Configuration**: Easily manage tool paths, API keys, wordlists, and concurrency settings from a single `config.yaml` file.

## Workflow Phases

1.  **Enumeration**: Gathers subdomains using a battery of passive tools, with an option for active brute-forcing.
2.  **Scanning & Probing**: Identifies live hosts, probes for open ports, and fingerprints web technologies.
3.  **Discovery & Analysis**: Discovers endpoints from historical archives, checks for known vulnerabilities with Nuclei, and hunts for leaked secrets.

## Installation

1.  **Clone the repository & navigate to the directory.**
2.  **Install Go**: Ensure that the Go programming language is installed on your system.
3.  **Make the setup script executable**:
    ```bash
    chmod +x setup.sh
    ```
4.  **Run the setup script**:
    ```bash
    ./setup.sh
    ```
    This will install Python dependencies and all required third-party tools.
5.  **Configure the Tool**:
    -   Update `config.yaml` with the correct paths to your wordlists.
    -   Add any necessary API keys to `config.yaml`.

## Usage

**Run a default (passive) scan:**
```bash
python3 main.py -t example.com
```

**Run a deep (active) scan:**
```bash
python3 main.py -t example.com --deep
```

**Specify a custom output directory:**
```bash
python3 main.py -t example.com -o /path/to/output
```