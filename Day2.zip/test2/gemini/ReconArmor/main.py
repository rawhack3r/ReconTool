# main.py
import argparse
import os
import yaml
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
from rich.live import Live

# Import phase runners
from phases import enumerate, scan, discover

def show_banner(console):
    """Displays a cool banner for the tool."""
    banner = "[bold magenta]🛡️ ReconArmor v1.0 🛡️[/bold magenta]\n[cyan]Your Advanced Reconnaissance Framework[/cyan]"
    console.print(Panel(banner, expand=False, border_style="bold green"), justify="center")
    console.print()

def load_config():
    """Loads the configuration from config.yaml."""
    with open('config.yaml', 'r') as f:
        return yaml.safe_load(f)

def run_workflow(target, deep_scan, output_dir, console):
    """Manages the entire reconnaissance workflow."""
    config = load_config()
    os.makedirs(output_dir, exist_ok=True)
    
    progress_bar = Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}", justify="right"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        TimeElapsedColumn(),
        console=console
    )
    
    with Live(progress_bar, refresh_per_second=10):
        # Phase 1: Enumeration
        enumerate.run(target, output_dir, deep_scan, config, progress_bar)
        
        # Phase 2: Scanning & Probing
        scan.run(target, output_dir, deep_scan, config, progress_bar)
        
        # Phase 3: Discovery & Analysis
        discover.run(target, output_dir, config, progress_bar)

if __name__ == "__main__":
    console = Console()
    show_banner(console)

    parser = argparse.ArgumentParser(description="ReconArmor - Advanced Reconnaissance Framework.")
    parser.add_argument("-t", "--target", help="The target domain to scan.", required=True)
    parser.add_argument("-d", "--deep", help="Enable deep scan (active enumeration, full port scans).", action="store_true")
    parser.add_argument("-o", "--output", help="Directory to save output files.", default="results")

    args = parser.parse_args()
    
    output_path = os.path.join(args.output, args.target)

    try:
        run_workflow(args.target, args.deep, output_path, console)
        console.print(f"\n[bold bright_green]✅ Reconnaissance complete! Results saved in '{output_path}'[/bold bright_green]")
        console.print(f"[yellow]⚠️ Check 'recon_errors.log' for any commands that may have failed.[/yellow]")
    except Exception as e:
        console.print(f"[bold red]❌ An unexpected critical error occurred: {e}[/bold red]")