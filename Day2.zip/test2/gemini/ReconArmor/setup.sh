#!/bin/bash
# setup.sh

echo "[+] 🛡️ Installing Python dependencies..."
pip3 install -r requirements.txt

echo "[+] 🛡️ Installing necessary Go tools... (This requires Go to be installed and configured)"

# Check if Go is installed
if ! command -v go &> /dev/null
then
    echo "[!] Go is not installed. Please install Go and ensure '~/go/bin' is in your \$PATH."
    exit 1
fi

echo "[*] Installing Subdomain Enumeration tools..."
go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install -v github.com/OWASP/Amass/v3/...@master
go install -v github.com/tomnomnom/assetfinder@latest

echo "[*] Installing Scanning & Probing tools..."
go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest
go install -v github.com/projectdiscovery/naabu/v2/cmd/naabu@latest

echo "[*] Installing Discovery & Analysis tools..."
go install -v github.com/projectdiscovery/nuclei/v2/cmd/nuclei@latest
go install -v github.com/tomnomnom/waybackurls@latest
go install -v github.com/lc/gau/v2/cmd/gau@latest
go install -v github.com/tomnomnom/gf@latest

echo "[+] 🛡️ Setup complete! Please update config.yaml with your wordlist paths."
echo "[+] Ensure '~/go/bin' is in your \$PATH to make the tools accessible."