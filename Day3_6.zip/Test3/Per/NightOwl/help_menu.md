# NightOwl Usage
python core/main.py --target example.com --mode deep

Modes:
  light:  Fast/passive only
  deep:   All phases, incl. brute, secrets, screenshots

All config in configs/tools.yaml. Resume and retry logic built-in.
