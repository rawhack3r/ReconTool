TOOL_OUTPUT_DIR = "outputs"
ERROR_FILE = "error.log"
STATE_FILE = "resume.json"
