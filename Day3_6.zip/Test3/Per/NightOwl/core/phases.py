PHASES = {
    "Subdomain Enumeration": "Phase 1",
    "Endpoint Discovery": "Phase 2",
    "Live Host Probing": "Phase 3",
    "Vulnerability Scanning": "Phase 4",
    "Secrets Disclosure": "Phase 5",
    "Screenshots": "Phase 6"
}
