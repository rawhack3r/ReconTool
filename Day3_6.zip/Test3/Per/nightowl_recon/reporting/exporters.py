from pathlib import Path

def export_to_excel(scan_results, summary_stats, output_path):
    # Placeholder: implement using pandas if needed
    pass

def export_to_markdown(scan_results, summary_stats, output_path):
    # Placeholder: implement as needed
    pass
