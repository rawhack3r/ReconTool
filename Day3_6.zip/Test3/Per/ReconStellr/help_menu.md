# ReconStellr Usage
python core/main.py --target example.com --mode deep

Modes:
  light:  Fast, passive-only
  deep:   All phases, includes brute and vulnerable scanning

All config in configs/tools.yaml. Tools auto-merge outputs. Resume is automatic on crash/ctrl+c.
