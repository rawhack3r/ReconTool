from pathlib import Path

OUTPUT_ROOT = Path("outputs")

ICONS = {
    "success": "✅",
    "fail": "❌",
    "running": "⏳"
}
