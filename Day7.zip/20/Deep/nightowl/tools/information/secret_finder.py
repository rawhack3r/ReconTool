from core.utils import Utils

def run(content):
    return Utils.extract_secrets(content)