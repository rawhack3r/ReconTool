from core.utils import Utils

def run(domains):
    return Utils.find_buckets(domains)