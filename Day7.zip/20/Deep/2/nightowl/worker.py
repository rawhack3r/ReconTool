#!/usr/bin/env python3
from workers.scanner import worker_process

if __name__ == "__main__":
    worker_process()