
import unittest
from core.tools import run_sublist3r, run_amass, check_tool_availability

class TestTools(unittest.TestCase):
    def test_sublist3r(self):
        results, stderr, duration, cpu, ram, net_sent, net_recv = run_sublist3r("example.com")
        self.assertIsInstance(results, list)
        self.assertIsInstance(stderr, str)
        self.assertIsInstance(duration, float)
        self.assertIsInstance(cpu, float)
        self.assertIsInstance(ram, float)
        self.assertIsInstance(net_sent, float)
        self.assertIsInstance(net_recv, float)

    def test_amass(self):
        results, stderr, duration, cpu, ram, net_sent, net_recv = run_amass("example.com")
        self.assertIsInstance(results, list)
        self.assertIsInstance(stderr, str)
        self.assertIsInstance(duration, float)
        self.assertIsInstance(cpu, float)
        self.assertIsInstance(ram, float)
        self.assertIsInstance(net_sent, float)
        self.assertIsInstance(net_recv, float)

    def test_check_tool_availability(self):
        self.assertTrue(check_tool_availability("crt_sh", {"general": {"wordlist_dir": "data/wordlists"}}))
        self.assertFalse(check_tool_availability("nonexistent_tool", {"general": {"wordlist_dir": "data/wordlists"}}))

if __name__ == "__main__":
    unittest.main()