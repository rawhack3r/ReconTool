
import unittest
from core.ui import UI

class TestUI(unittest.TestCase):
    def test_ui_initialization(self):
        ui = UI()
        self.assertIsNotNone(ui.console)
        self.assertIsNotNone(ui.layout)
        self.assertIsNotNone(ui.progress)

    def test_start_scan(self):
        ui = UI()
        ui.start_scan("example.com", "light")
        self.assertEqual(ui.current_target, "example.com")
        self.assertEqual(ui.current_mode, "light")

if __name__ == "__main__":
    unittest.main()