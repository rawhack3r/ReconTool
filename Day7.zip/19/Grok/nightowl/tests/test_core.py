import unittest
from core.ai_orchestrator import AIOrchestrator
from core.error_handler import ErrorHandler

class TestCore(unittest.TestCase):
    def test_ai_orchestrator(self):
        orchestrator = AIOrchestrator("dummy_key")
        recommendations = orchestrator.recommend_tools("example.com", {}, "deep", "single")
        self.assertIsInstance(recommendations, list)

    def test_error_handler(self):
        ErrorHandler.log_error("Test error")
        self.assertIn("Test error", ErrorHandler.errors)