import unittest
import os
from tools.subdomain_enum.subfinder_wrapper import run_subfinder
from tools.secret_finder.trufflehog_wrapper import run_trufflehog
from tools.endpoint_enum.katana_wrapper import run_katana
from tools.vulnerability.nuclei_wrapper import run_nuclei

class TestTools(unittest.TestCase):
    def setUp(self):
        os.makedirs("output", exist_ok=True)

    def test_subfinder(self):
        results = run_subfinder("example.com", "output/subfinder_test.txt")
        self.assertIsInstance(results, list)

    def test_trufflehog(self):
        results = run_trufflehog("http://example.com", "output/trufflehog_test.txt")
        self.assertIsInstance(results, list)

    def test_katana(self):
        results = run_katana("http://example.com", "output/katana_test.txt")
        self.assertIsInstance(results, list)

    def test_nuclei(self):
        results = run_nuclei("http://example.com", "output/nuclei_test.txt")
        self.assertIsInstance(results, list)

if __name__ == '__main__':
    unittest.main()