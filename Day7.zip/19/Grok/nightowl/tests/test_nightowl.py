
import unittest
import os
from nightowl.core.phase_workflow import PhaseWorkflow
from nightowl.core.error_handler import ErrorHandler

class TestNightOwl(unittest.TestCase):
    def setUp(self):
        ErrorHandler.setup_logging()
        self.workflow = PhaseWorkflow("light", "example.com")

    def test_tool_availability(self):
        async def check():
            self.assertTrue(await self.workflow.is_tool_available("subfinder"))
        asyncio.run(check())

    def test_phase_workflow(self):
        self.assertEqual(self.workflow.get_phases(), [
            "Subdomain Enumeration",
            "Secret Finding",
            "Endpoint Extraction",
            "Vulnerability Scanning",
            "Cloud and IP Discovery"
        ])

    def test_error_logging(self):
        ErrorHandler.log_error("Test error")
        with open("logs/error.log", "r") as f:
            self.assertIn("Test error", f.read())

if __name__ == "__main__":
    unittest.main()