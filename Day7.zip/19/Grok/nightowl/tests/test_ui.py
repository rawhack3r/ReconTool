import unittest
from ui.dashboard import display_dashboard
from ui.progress import ProgressTracker
from core.resource_monitor import ResourceMonitor

class TestUI(unittest.TestCase):
    def test_dashboard(self):
        resources = ResourceMonitor.get_resources()
        target_info = {'domain': 'example.com', 'mode': 'deep', 'type': 'single'}
        phases = {"Subdomain Enumeration": "In Progress"}
        tools = [{'name': 'subfinder', 'progress': 50, 'status': 'Running', 'start_time': 0, 'duration': 0, 'results': '0 items'}]
        try:
            display_dashboard("Running", resources, target_info, phases, tools)
            self.assertTrue(True)
        except Exception:
            self.assertTrue(False)

    def test_progress_tracker(self):
        with ProgressTracker() as tracker:
            task_id = tracker.add_task("Test Task")
            tracker.update(task_id, 50)
            self.assertTrue(True)

if __name__ == '__main__':
    unittest.main()