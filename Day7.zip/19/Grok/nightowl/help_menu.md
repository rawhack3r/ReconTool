NightOwl Help Menu
Command-Line Options
--target      Target domain or file with list of domains
--mode        Scan mode: light, deep, deeper, custom
--custom-tools  List of tools for custom mode (e.g., subfinder amass)
--resume      Resume interrupted scan
--retry-failed  Retry failed tools

Modes

light: Runs findomain, crt_sh, subfinder.
deep: Runs all tools.
deeper: Same as deep with extended permutations.
custom: User-specified tools.

Outputs

Per-tool results: output/<tool>_<target>.txt
Merged results: output/final_<target>.txt
Live hosts: output/live_<target>.txt
Non-resolved hosts: output/non_resolved_<target>.txt
Important assets: output/important_<target>.txt
Secrets: output/secrets_<target>.txt
Vulnerabilities: output/vulns_<target>.txt
HTML report: output/report_<target>.html

Dashboard
Run python3 dashboard.py and access http://localhost:5000.
Error Handling

Errors logged to logs/error.log.
Tool outputs in logs/tool_output_<tool>.log.
Run --retry-failed to retry failed tools.

Manual Review

Check sensitive_domains in HTML report for high-value targets.
Verify secrets and vulnerabilities manually.
